package com.example.lab4;

import jakarta.jms.*;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.lang.management.ManagementFactory;

import com.sun.management.OperatingSystemMXBean;

@Component
public class ChartDataScheduler {

    private static final String BROKER_URL = "tcp://localhost:61616";
    private static final String CHAT_TOPIC = "chatTopic";
    private static final String USER_NAME = "user2";

    @Scheduled(fixedRate = 5000) // 每5秒发送一次数据
    // 或者@Scheduled(cron = "0 0 12 * * ?")每天中午12点执行
    public void sendDataToClients() {
        try {
            //与ActiveMq建立连接
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(BROKER_URL);
            Connection connection = connectionFactory.createConnection();
            connection.setClientID(USER_NAME);
            connection.start();
            //设定消息确认模式（此处是自动确认）和TOPIC
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topic = session.createTopic(CHAT_TOPIC);
            MessageProducer producer = session.createProducer(topic);
            //发送文本消息
            String messageText = generateData();
            TextMessage textMessage = session.createTextMessage(USER_NAME + ": " + messageText);
            producer.send(textMessage);
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String generateData() {
        String s = "";
        OperatingSystemMXBean osBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();

        // 获取系统处理器信息
        s += "系统处理器数目：" + osBean.getAvailableProcessors() + "\n";
        s += "系统处理机占用：" + osBean.getSystemCpuLoad() * 100 + "%" + "\n";

        // 获取系统内存信息
        long totalMemorySize = Runtime.getRuntime().totalMemory(); // 总内存
        long freeMemorySize = Runtime.getRuntime().freeMemory();   // 空闲内存
        long maxMemorySize = Runtime.getRuntime().maxMemory();     // 最大内存
        s += "总内存：" + totalMemorySize / (1024 * 1024) + " MB" + "\n";
        s += "空闲内存：" + freeMemorySize / (1024 * 1024) + " MB" + "\n";
        s += "最大内存：" + maxMemorySize / (1024 * 1024) + " MB" + "\n";
        // 模拟生成数据的逻辑
        return s;
    }
}
