package com.example.lab4;

import jakarta.jms.*;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
public class Lab4Application {

	private static final String BROKER_URL = "tcp://localhost:61616";
	private static final String CHAT_TOPIC = "chatTopic";
	private static final String USER_NAME = "user1";

	public static void main(String[] args) {
		SpringApplication.run(Lab4Application.class, args);

		try {
			//与ActiveMq建立连接
			ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(BROKER_URL);
			Connection connection = connectionFactory.createConnection();
			connection.setClientID(USER_NAME);
			connection.start();

			//设定消息确认模式（此处是自动确认）和TOPIC
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Topic topic = session.createTopic(CHAT_TOPIC);

			//创建消息监听事件，便于收到其他用户消息
			MessageConsumer consumer = session.createDurableSubscriber(topic, USER_NAME);
			consumer.setMessageListener(message -> {
				String receivedMessage = null;
				try {
					receivedMessage = ((TextMessage) message).getText();
				} catch (JMSException e) {
					throw new RuntimeException(e);
				}
				System.out.println("Received: " + receivedMessage);
			});
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

}
