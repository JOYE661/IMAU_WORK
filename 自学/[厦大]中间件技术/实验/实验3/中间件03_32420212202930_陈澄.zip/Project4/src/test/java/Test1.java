
import org.junit.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Random;

public class Test1 {
    @Test
    public void test() throws Exception {
        Random random = new Random();
        String q = "你好";
        String appId = "";
        String salt = String.valueOf(random.nextInt());
        String key = "";

        String s = appId+q+salt+key;
        String md5S = "";

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(s.getBytes());

            byte[] digest = md.digest();

            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
            }

            md5S = sb.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        URL url = new URL("http://api.fanyi.baidu.com/api/trans/vip/translate?" +
                "q=" + q +
                "&from=zh&to=cht" +
                "&appid=" + appId +
                "&salt=" + salt +
                "&sign=" + md5S); // 设置请求的URL
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        // 设置请求方法为GET
        connection.setRequestMethod("GET");

        // 获取响应内容
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        System.out.println(response);
    }

    @Test
    public void md5(){
        String s = "apple";
        String md5S;

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(s.getBytes());

            byte[] digest = md.digest();

            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
            }

            md5S = sb.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
