#ifndef _rs485_H
#define _rs485_H

#include "sys.h"
#include "delay.h"

void rs485_init(u32 baund);   //485��ʼ��


#endif
