package U11_22;

public class Task1122 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
}
