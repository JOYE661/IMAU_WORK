import java.util.Scanner;
public class Class3_02HelloWorld {
//�ݸ�ֽ
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input;
		input=new Scanner(System.in);
		int a=input.nextInt();
		System.out.println(a);
	}

}
