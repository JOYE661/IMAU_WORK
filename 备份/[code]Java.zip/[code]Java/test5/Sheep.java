package test5;
public class Sheep extends Animal implements Edible{
	//sound getH setH setW
	@Override
	public void sound() {
		System.out.println("Sheep:sound");
	}
	public void eat() {
		System.out.println("����");
	}
}
