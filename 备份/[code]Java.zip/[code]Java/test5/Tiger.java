package test5;
public class Tiger extends Animal{
	
	public void sound() {
		System.out.println("Tiger:sound");
	}
}
