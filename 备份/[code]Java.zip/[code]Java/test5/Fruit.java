package test5;
public abstract class Fruit implements Edible{
	private double color;
	
	public void setC(double color) {
		this.color=color;
	}
	public double getc() {
		return color;
	}
}
