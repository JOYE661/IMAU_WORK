package test5;
public class Orange extends Fruit{
	@Override
	public void eat() {
		System.out.println("�Ե�����");
	}
}
