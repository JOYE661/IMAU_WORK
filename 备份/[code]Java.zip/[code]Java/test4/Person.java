package test4;

public class Person {
	private String name;
	private String area;
	private String telephone;
	private String e_mail;
	
	public String getname() {
		return this.name;
	}
	public String getarea() {
		return this.area;
	}
	public String gettelephone() {
		return this.telephone;
	}
	public String gete_mail() {
		return this.e_mail;
	}
	public void setname(String name) {
		this.name=name;
	}
	public void setarea(String area) {
		this.area=area;
	}
	public void settelephone(String telephone) {
		this.telephone=telephone;
	}
	public void sete_mail(String e_mail) {
		this.e_mail=e_mail;
	}
	
	public Person() {
		
	}
}
