package test4;

public class staff extends employee{
	@Override
	public String toString() {
		return "staff"+super.getname();
	}

}
