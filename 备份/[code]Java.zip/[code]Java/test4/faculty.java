package test4;

public class faculty extends employee{
	@Override
	public String toString() {
		return "faculty"+super.getname();
	}
}
