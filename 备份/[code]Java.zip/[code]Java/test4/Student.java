package test4;

public class Student extends Person{
	@Override
	public String toString() {
		return "Student"+super.getname();
	}
}
