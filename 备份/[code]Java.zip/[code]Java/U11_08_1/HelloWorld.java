package U11_08_1;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
