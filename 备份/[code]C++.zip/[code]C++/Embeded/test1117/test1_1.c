#include<stdio.h>
int main(){
    int *pa;
    char *pc;
    double *pd;
}

