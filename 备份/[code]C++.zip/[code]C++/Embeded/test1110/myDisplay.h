#ifndef _MYDISPLAY_H
#define _MYDISPLAY_H

void display(int a[], int n);
#endif
