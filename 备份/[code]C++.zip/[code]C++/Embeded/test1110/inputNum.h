#ifndef _INPUTNUM_H
#define _INPUTNUM_H
void readNums(int arr[],int n);


#endif
