#include<stdio.h>
#include"Caculator.h"
#include"myDisplay.h"
void display(int a[],int n){
    printf("sum=:%d\n",sumNums(a,n));
}

