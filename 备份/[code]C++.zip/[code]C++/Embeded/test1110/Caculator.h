#ifndef _CACULATOR_H
#define _CACULATOR_H

int sumNums(int arr[],int n);
#endif
