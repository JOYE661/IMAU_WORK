#!/bin/bash
grep "bin" /etc/passwd > file
