#!/bin/bash
echo "zhouye 2021122156404 cs3"> f1.txt
echo "this is my Embedded Basic Practice class"> f2.txt
mkdir d1
mkdir -p d2/d3
cp f1.txt d1/
cp f2.txt d2/d3
cat f1.txt f2.txt>f3.txt
