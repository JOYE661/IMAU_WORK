#include<stdio.h>
#include"mj.h"
float mj(float r)
{
    return 3.14*r*r;
}
