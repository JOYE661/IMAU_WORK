//function  workspace
#include<stdio.h>
double fun1(double r){
    return 3.14*r*r
}
double fun2(double r){
    return 3.14*r*2
}


