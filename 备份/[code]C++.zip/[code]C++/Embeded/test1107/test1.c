#include<stdio.h>
int main()
{
    printf("fuck");
    return 0;
}

