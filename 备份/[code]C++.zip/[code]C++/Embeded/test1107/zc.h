#ifndef _ZC_H
#define _ZC_H

float zc(float r);

#endif
