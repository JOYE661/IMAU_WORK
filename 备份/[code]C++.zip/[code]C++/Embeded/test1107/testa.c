//ask for a circle
#include<stdio.h>

int main()
{
    float r;
    scanf("%f",&r);
    return 0;
}
