#ifndef _MJ_H
#define _MJ_H

float mj(float r);
#endif
