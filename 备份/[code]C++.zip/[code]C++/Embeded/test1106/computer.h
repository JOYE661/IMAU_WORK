#ifndef _COMPUTER_H_
#define _COMPUTER_H_

int sum(int a,int b);

#endif
