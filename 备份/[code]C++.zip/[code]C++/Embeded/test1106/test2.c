#include<stdio.h>
void fun(void){
    printf("u r in fun!\n");
    
}

