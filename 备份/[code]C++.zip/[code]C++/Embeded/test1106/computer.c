#include<stdio.h>
#include"computer.h"
int sum(int a,int b){
    return a+b;
}

