//顺序表递增有序，插入元素x，仍旧递增有序
#include<stdio.h>
typedef struct 
{
  int date[100]; /* data */
  int length;
}Sqlist;
int main()
{
  printf("hello world\n");
  return 0;
}
