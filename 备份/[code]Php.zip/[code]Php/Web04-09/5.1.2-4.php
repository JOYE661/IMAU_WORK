<?php
// 不合法的变量名
$123a = 'test';    // 错误信息“Parse error: syntax error...”
