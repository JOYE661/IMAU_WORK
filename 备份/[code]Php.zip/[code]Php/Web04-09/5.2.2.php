<?php
// error_reporting = E_ALL
// log_error = On
// error_log = C:/web/php_errors.log

error_log('error message a');

error_log('error message b', 3, 'C:/web/php.log');
