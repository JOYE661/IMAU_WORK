<?php
display();			// 错误信息“Fatal error: Uncaught Error: Call to undefined function...”
echo 'test';		// 前一行发生错误，此行代码不会执行
