<?php
// zend_extension = C:/web/php7.2/ext/php_xdebug-3.0.4-7.2-vc15.dll

function getFile()
{
    require 'outfile.php';	 // 引入外部文件
}
getFile();
