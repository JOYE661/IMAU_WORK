<?php
// error_reporting = E_ALL & ~E_NOTICE
// display_errors = On

error_reporting(E_ALL & ~E_NOTICE);
ini_set('display_errors', 1);
