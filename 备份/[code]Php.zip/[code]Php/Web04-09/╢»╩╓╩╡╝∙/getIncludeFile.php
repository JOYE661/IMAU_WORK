<?php
include './a.php';
print_r(get_included_files());		// 获取已加载文件列表
