<?php
if (version_compare(PHP_VERSION, '7.2', '<')) {
    exit ('您的PHP版本低于7.2，无法运行此脚本！');
}
