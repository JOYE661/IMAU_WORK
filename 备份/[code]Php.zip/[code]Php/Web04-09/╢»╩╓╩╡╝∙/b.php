<?php
include './c.php';
