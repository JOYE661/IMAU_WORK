<?php
echo 5 + 5;
echo '<br>';

echo 6 - 4;
echo '<br>';

echo 3 * 4;
echo '<br>';

echo 5 / 5;
echo '<br>';

echo 7 % 5;
echo '<br>';

echo 3 ** 4;
echo '<br>';

echo 1 + 2 * 3;
echo '<br>';

echo (-8) % 7;
echo '<br>';

echo 8 % (-7);
