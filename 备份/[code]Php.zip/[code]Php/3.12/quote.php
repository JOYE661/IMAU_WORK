<?php
$number = 100;
echo '$number=', $number;
echo '<br>';
echo "$number=", $number;
