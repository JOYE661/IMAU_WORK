<?php
echo 'true';					// 方式1，输出结果：true
echo '<br>';
echo 'result=', 4;				// 方式2，输出结果：result=4
echo '<br>';

print '生命在于运动！'; 	    // 输出结果：生命在于运动！
echo '<br>';

print_r('hello');				// 输出结果：hello
echo '<br>';

var_dump(2);					// 输出结果：int(2) 
echo '<br>';
var_dump('PHP', 'C');			// 输出结果：string(3) "PHP" string(1) "C" 
