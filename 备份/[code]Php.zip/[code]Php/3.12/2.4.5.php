<?php
$a = 1;
$b = 0;

var_dump($a && $b);
var_dump($a || $b);
var_dump(!$a);
var_dump($a xor $b);
var_dump($a and $b);
var_dump($a or $b);
