<?php
$a = 2;
$b = ++$a;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 2;
$b = $a++;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 2;
$b = --$a;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 2;
$b = $a--;
echo '$a=' . $a . ', $b=' . $b . '<br>';
