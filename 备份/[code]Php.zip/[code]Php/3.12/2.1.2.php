<?php

echo 'Hello, PHP';    // 单行注释

echo '<br>';

echo 'Hello, PHP';    # 单行注释

echo '<br>';

/*
   多行注释
*/
echo 'Hello, PHP';
