<?php
var_dump(5 == 4);
var_dump(5 != 4);
var_dump(5 <> 4);
var_dump(5 === 5);
var_dump(5 !== '5');
var_dump(5 > 5);
var_dump(5 >= 5);
var_dump(5 < 5);
var_dump(5 <= 5);
