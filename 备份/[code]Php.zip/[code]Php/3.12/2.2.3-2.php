<?php
const P = 2 * R;
echo 'P=', P;	              // 输出结果：P=12
