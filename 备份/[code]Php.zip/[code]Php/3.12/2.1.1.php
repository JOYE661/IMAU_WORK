<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <p>Hello HTML </p>
  <p><?php echo 'Hello, PHP'; ?></p>
</body>
</html>