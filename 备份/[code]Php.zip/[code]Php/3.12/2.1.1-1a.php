<?php
echo 'Hello, PHP'; 
