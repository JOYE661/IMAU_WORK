<?php
const R = 6;
echo 'R=', R;	              // 输出结果：R=6
