<?php

$a = 3;
$b = 2;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 3;
$b = 2;
$a += $b;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 3;
$b = 2;
$a -= $b;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 3;
$b = 2;
$a *= $b;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 3;
$b = 2;
$a /= $b;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 3;
$b = 2;
$a %= $b;
echo '$a=' . $a . ', $b=' . $b . '<br>';

$a = 'abc';
$a .= 'def';
echo '$a=' . $a . '<br>';

$a = 2;
$a **= 5;
echo '$a=' . $a . '<br>';

$first = $second = $third = 3;		// 为3个变量同时赋值

$a = 5;
$a += 4;

$str = 'I love ';
$str .= 'PHP';

$str = $str . 'PHP';
