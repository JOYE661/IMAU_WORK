<?php
$a = 'say';
$say = 'Hello';
$Hello = 'Lucy';
echo '$a变量的值：', $a;
echo '<br>';
echo '$$a变量的值：', $$a;
echo '<br>';
echo '$$$a变量的值：', $$$a;
