<?php
$str = 'learning';
$html = 'Welcome to ' . $str . ' PHP';
echo $html;			// 输出结果：Welcome to learning PHP
