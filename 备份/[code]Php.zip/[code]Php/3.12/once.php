<?php
$sum = $i++;
