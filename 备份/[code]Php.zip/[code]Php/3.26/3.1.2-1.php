<?php
function shout()
{
    return 'come on';
}
echo shout();		// 输出结果：come on
