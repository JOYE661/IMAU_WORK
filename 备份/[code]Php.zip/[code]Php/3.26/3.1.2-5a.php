<?php
declare(strict_types = 1);
function sum2(int $a, int $b)
{
    return $a + $b;
}
echo sum2(2.6, 3.8); // 输出结果：Fatal error: ......
