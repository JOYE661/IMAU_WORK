<?php
function shout()
{
    echo 'come on....';
}
$funcname = 'shout';		// 定义变量，其值是函数的名称
echo $funcname();			// 利用可变变量调用函数
