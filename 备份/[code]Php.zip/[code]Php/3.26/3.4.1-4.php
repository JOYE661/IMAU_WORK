<?php
if (strcmp('ye_PHP', 'yePHP')) {
    echo 'not the same string';
} else {
    echo 'the same string';
}
