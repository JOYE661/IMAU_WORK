<?php
$sum = function($a, $b) {	// 定义匿名函数
    return $a + $b;
};
echo $sum(100, 200);		// 输出结果：300
