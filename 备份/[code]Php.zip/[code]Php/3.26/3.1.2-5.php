<?php
function sum(int $a, int $b)
{
    return $a + $b;
}
echo sum(2.6, 3.8); 	// 输出结果：5
