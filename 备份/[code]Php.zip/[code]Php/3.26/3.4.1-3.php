<?php
$str = '   These are a few words :) ...   ';
echo '原字符串：' . $str . '<br>';
echo '去空白后的字符串：' . trim($str);
