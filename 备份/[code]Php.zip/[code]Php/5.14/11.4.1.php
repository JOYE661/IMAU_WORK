<?php
class Student
{
    const SCHOOL = '某学院';	 // 定义类常量
}
echo Student::SCHOOL;   		 // 访问类常量
