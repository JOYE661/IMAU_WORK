<?php
echo $_SERVER['HTTP_REFERER'];
