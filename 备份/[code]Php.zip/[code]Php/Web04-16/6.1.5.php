<?php
// 设定编码格式
header('Content-Type: text/html; charset=UTF-8');
// 页面重定向
header('Location: login.php');
