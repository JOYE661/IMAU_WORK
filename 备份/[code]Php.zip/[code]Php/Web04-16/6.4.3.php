<?php
session_start(['name' => 'MySESSID']);