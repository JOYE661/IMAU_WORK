<?php
setcookie('name', 'value', 0, '/');         // 当前整个网站都可访问
setcookie('name', 'value', 0, '/', '.com'); // 所有.com的网站都可以访问
