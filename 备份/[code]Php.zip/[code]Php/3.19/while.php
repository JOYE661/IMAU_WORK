<?php
$i = 5;
while ($i > 0) {
    echo '☆';
    $i--;
}
