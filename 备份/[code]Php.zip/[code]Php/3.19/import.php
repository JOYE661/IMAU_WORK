<?php
include './wrongFile.php';			// 产生一个警告
// require './wrongFile.php');			// 产生一个致命错误
echo 'Hello,PHP';					// 此句会执行
