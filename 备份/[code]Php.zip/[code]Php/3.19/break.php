<?php
$i = 1;
while (true) {
    echo $i . '.PHP基础案例教程<br>';
    if ($i++ == 3) {
        break;
    }
}
