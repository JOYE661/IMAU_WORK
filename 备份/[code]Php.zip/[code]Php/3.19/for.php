<?php
for ($i = 5; $i > 0; $i--) {
    echo '☆';
}
