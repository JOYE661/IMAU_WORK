<?php
$i = 5;
do {
    echo '☆';
    $i--;
} while ($i > 0);
