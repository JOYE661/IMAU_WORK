<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?php echo '这是标题'; ?></title>
    <style>
      body { background-color: <?php echo 'black'; ?>; }
    </style>
    <script>
      alert(<?php echo 10 + 20; ?>);
    </script>
  </head>
  <body>
    <font color="<?php echo 'white'; ?>">
      <?php echo '<strong>PHP</strong>基础案例教程'; ?>
    </font>
  </body>
</html>