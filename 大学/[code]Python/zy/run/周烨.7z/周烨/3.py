F=int(input('华氏温度'))
C=(F-32)*5/9
print(C)
