print('Life is short. I use python.')
