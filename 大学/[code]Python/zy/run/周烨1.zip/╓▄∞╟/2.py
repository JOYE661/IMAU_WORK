n=int(input('大于100的整数'))
a=round(n//10)
print("十位以上的数字是",a)
