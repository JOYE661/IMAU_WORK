a=int(input('输入第一条直角边'))
b=int(input('输入第二条直角边'))
import math
c=math.sqrt(a**2+b**2)
print("对应的斜边",c)
